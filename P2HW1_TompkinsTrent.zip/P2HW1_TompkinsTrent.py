
# A code for calculating travel espenses

# 6/8/2023

# CTI-110 P1HW2 - Travel Expense

# TompkinsTrent

print('Enter your budget number')
budget = int(input())
print('Enter your  destination')
des = input()
print('Enter your gas expence number')
gas = int(input())
print('Enter your accomodation expence number')
acc= int(input())
print('Enter your food expence number')
food = int(input())

expences = gas + acc + food
postBudget = budget - expences


print('-------------Total-------------')
print('Destination:        ',des)
print('Budget:            ','${}'.format(budget))
print('Gas cost:          ','${}'.format(gas))
print('Accomodation cost: ','${}'.format(acc))
print('Food cost:         ','${}'.format(food))
print('Total expence:     ','${}'.format(expences))
print('-------------------------------')
print()
print('Remaining balence: ','${}'.format(postBudget))

if postBudget < 0:
    print('You have gone negative!')



