# CTI-110
# P2HW2 - List
# Trent Tompkins
# 6/13/2023
#
module = [int(input('Enter grade for module 1:')),
          int(input('Enter grade for module 2:')),
          int(input('Enter grade for module 3:')),
          int(input('Enter grade for module 4:')),
          int(input('Enter grade for module 5:')),
          int(input('Enter grade for module 6:'))]
avg = sum(module)/len(module)
mini = min(module)
maxi = max(module)
sumi = sum(module)
print('----------results-----------')
print('Lowest Grade:     ', mini)
print('Highest Grade:    ', maxi)
print('Sum of Grades:    ', sumi)
print('Average:          ', avg)




