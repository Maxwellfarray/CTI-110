milage = float(input())
cost = float(input())

twenty = (20/milage)*cost
seventyfive = (75/milage)*cost
fivehundred = (500/milage)*cost

print(f'{twenty:.2f} {seventyfive:.2f} {fivehundred:.2f}')