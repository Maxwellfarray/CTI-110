# CTI-110
# P4HW1 - Score List
# Trent Tompkins
# 7/6/2023
#
varified = False
while varified == False:
    numOfLoop = int(input('How many scores do you wart to enter?: '))
    if numOfLoop > 1:
        varified = True
    else:
        print('number must be greater than 1')
i = 1
score = [0]
while i <= numOfLoop:
    varified = False
    if i != 1:
        score.append(i)
    while varified == False:
        print('Enter score #{}: '.format(i), end = '')
        score[i-1] = int(input())
        if 0 <= score[i-1] <= 100:
            varified = True
        else:
            print('invalid input. number must be between 0-100. re-enter score #{}'.format(i))
    i += 1
low = min(score)
score.pop(score.index(low))
high = max(score)
avg = sum(score) / len(score)
if avg >= 90:
    grade = 'A'
elif 90 > avg >= 80:
    grade = 'B'
elif 80 > avg >= 70:
    grade = 'C'
elif 70 > avg >= 60:
    grade = 'D'
else:
    grade = 'f'
print('------------Results--------------')
print('Lowest score  :',low)
print('Modified list :',score)
print('Scores Average:',avg)
print('Grade         :',grade)
print('----------------------------------')
