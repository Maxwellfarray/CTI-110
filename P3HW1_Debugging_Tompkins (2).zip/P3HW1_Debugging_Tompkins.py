# I was supposed to put a comment here
# My Last Name


# This program takes a number grade , determines average and displays letter grade for average.

# Enter grades for six modules

mod_1 = int(input('Enter grade for Module 1: '))
mod_2 = int(input('Enter grade for Module 2: '))
mod_3 = int(input('Enter grade for Module 3: '))
mod_4 = int(input('Enter grade for Module 1: '))
mod_5 = int(input('Enter grade for Module 5: '))
mod_6 = int(input('Enter grade for Module 6: '))

# add grades entered to a list

grades = [mod_1, mod_2, mod_3, mod_4, mod_5]
# TO DO: determine lowest, highest , sum and average for grades

low = min(grades)
high = max(grades)
summ = sum(grades)
length = len(grades)
avg = summ / length

# determine letter grade for average

print('------------Results------------')
print('Lowest Grade:      ',low)
print('Highest Grade:     ',high)
print('Sum of Grades:     ',summ)
print('Average:           ',avg)
print('----------------------------------------')

if avg >= 90:
    print('Your grade is: A')
elif 90 < avg >= 80:
    print('Your grade is: B')
elif 80 < avg >= 70:
    print('Your grade is: C')
elif 70 < avg >= 60:
    print('Your grade is: D')
else:
    print('Your grade is: F')






