# CTI-110
# P3HW2 - Salary
# Trent Tompkins
# 7/6/2023
#
name = input("Enter the name of employee: ")
i = 0
hours = 0
payRate = 0
totalNormalPay = 0
totalOvertimePay = 0
while name != "Done":
    overtime = 0
    overtimePay = 0
    if i != 0:
            name = input("Enter the name of employee or 'Done' to close (note: case sensitive): ")
    if name != "Done":
        hours = int(input("Enter the number of hours the employee worked this week: "))
        payRate = float(input("Enter the employee's pay rate: "))
        if hours > 40:
            overtime = hours - 40
            reghours = hours - overtime
            pay = payRate * reghours
            grossPay = payRate * hours
            overtimePay = payRate * overtime
        else:
            pay = payRate * hours
            grossPay = payRate * hours
        i += 1
        totalNormalPay = totalNormalPay + pay
        totalOvertimePay = totalOvertimePay + overtimePay
         
        print('------------------------------')
        print('employee name:    ',name)
        print()
        print('hours   Pay Rate   Overtime    OverTime Pay    RegHour Pay    Gross Pay')
        print('---------------------------------------------------------------------------')
        print(hours,'     ',payRate,'        ',overtime,'          $',overtimePay,'           $',pay,'         $',grossPay)
total = totalNormalPay + totalOvertimePay
print('total number of employees:',i)
print('Total amount paid for overtime: ${}'.format(totalOvertimePay))
print('Total amount paid for regular hours: ${}'.format(totalNormalPay))
print('total amount paid in gross: ${}'.format(total))
print('terminated')

