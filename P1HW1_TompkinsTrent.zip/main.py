print('Enter integer:')
userNum = int(input())
print('You entered:', userNum)
square = userNum * userNum
print(userNum,'squared is', square)
cube = userNum * userNum * userNum
print('And',userNum,'cubed is',cube,'!!')
print('Enter another integer:')
userNumS = int(input())
addition = userNum + userNumS
print(userNum,'+',userNumS,'is',addition)
multiple = userNum * userNumS
print(userNum,'*',userNumS,'is',multiple)