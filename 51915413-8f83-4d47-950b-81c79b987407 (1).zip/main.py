
input_year = int(input())
checker2 = input_year % 100
checker = input_year % 4
checker3 = input_year % 400
if checker == 0 and checker2 != 0 or checker3 == 0:
    print(input_year, '- leap year')
else:
    print(input_year, '- not a leap year')