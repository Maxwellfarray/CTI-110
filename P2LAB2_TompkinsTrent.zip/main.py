num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

output = num1*num2*num3*num4
avg = (num1+num2+num3+num4)/4

print(f'{output:.0f}',f'{avg:.0f}')
print(f'{output:.3f}',f'{avg:.3f}')